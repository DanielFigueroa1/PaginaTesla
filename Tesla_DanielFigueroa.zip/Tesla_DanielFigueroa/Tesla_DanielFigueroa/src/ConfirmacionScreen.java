import processing.core.PApplet;
import processing.core.PImage;

public class ConfirmacionScreen {
	
	private PApplet app;
	private PImage logoGris;
	private PImage espacio;
	private PImage datos;
	private PImage back;
	private PImage tareaNegra;
	private PImage casaNegra;
	private PImage carroBlanco;
	private PImage confirmar;
	private PImage fondo;
	private PImage confirmacion;
	private PImage cancelar;
	
	public ConfirmacionScreen(PApplet app){
		this.app = app;
		this.logoGris = app.loadImage("imagenes/Mask Group.png");
		this.tareaNegra = app.loadImage("imagenes/clipboard.png");
		this.espacio = app.loadImage("imagenes/Rectangle 1.png");
		this.datos = app.loadImage("imagenes/datosCompra.png");
		this.back = app.loadImage("imagenes/flecha.png");
		this.casaNegra = app.loadImage("imagenes/home.png");
		this.carroBlanco = app.loadImage("imagenes/Mask Group-1.png");
		this.confirmar = app.loadImage("imagenes/confirmar.png");
		this.fondo = app.loadImage("imagenes/gris.png");
		this.confirmacion = app.loadImage("imagenes/confirmacionDatos.png");
		this.cancelar = app.loadImage("imagenes/cancelar.png");
	}
	
	public void draw() {
		
		app.image(logoGris,94,200,160,200);
		app.image(fondo,0,0,350,600);
		app.image(espacio,50,165,250,50);
		app.image(espacio,50,256,250,50);
		app.image(espacio,50,344,250,50);
		app.image(datos,0,0,350,600);
		app.image(back,25,60,30,30);
		app.image(confirmacion,0,0,350,600);
		app.image(cancelar,111,380,130,40);
		app.image(confirmar,111,440,130,40);
		app.image(tareaNegra,40,564,30,30);
		app.image(casaNegra,160,564,30,30);
		app.image(carroBlanco,281,564,30,30);
	}
	
	public int Click(int screen){
		if(app.mouseX > 40 && app.mouseX < 70 && app.mouseY > 564 && app.mouseY < 594) {
	          return 2; //historia 40,564,30,30
		} 
		if(app.mouseX > 160 && app.mouseX < 190 && app.mouseY > 564 && app.mouseY < 594) {
			return 3; //catalogo 160,564,30,30
		} 
		if(app.mouseX > 281 && app.mouseX < 311 && app.mouseY > 564 && app.mouseY < 594) {
			return 1; //carro  281,564,30,30
		} 
		if(app.mouseX > 111 && app.mouseX < 241 && app.mouseY > 380 && app.mouseY < 420) {
			return 8; //Cancelar 111,380,130,40);
		} 
		if(app.mouseX > 111 && app.mouseX < 241 && app.mouseY > 440 && app.mouseY < 480) {
			return 10; //Confirmar 111,440,130,40);
		} 
		
		return screen;
	
	}
}
