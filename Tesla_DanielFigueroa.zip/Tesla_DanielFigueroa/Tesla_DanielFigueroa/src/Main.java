import processing.core.PApplet;
import processing.core.PImage;

public class Main extends PApplet {

	public static void main(String[] args) {

		PApplet.main("Main"); // no s� como es pero debo hacerlo

		//LETRA ROBOTO
	}
	
	int pantalla;
	LoginScreen loginScreen;
	HomeScreen homeScreen;
	HistorialScreen historialScreen;
	CatalogoScreen catalogoScreen;
	CatalogoSScreen catalogoSScreen;
	Catalogo3Screen catalogo3Screen;
	CatalogoXScreen catalogoXScreen;
	CarritoScreen carritoScreen;
	DatosScreen datosScreen;
	ConfirmacionScreen confirmacionScreen;
	CompletoScreen completoScreen;
	ComparacionCuadradosGraficaSScreen comparacionCuadradosGraficaSScreen;
	
	PImage logo;
	PImage logoGris;
	PImage login;
	PImage entrar;
	PImage espacio;
	PImage inicio;
	PImage casaNegra;
	PImage casaBlanca;
	PImage carroNegro;
	PImage carroBlanco;
	PImage tareaNegra;
	PImage tareaBlanca;
	PImage historial;
	PImage back;
	PImage ojo;
	PImage catalogo;
	PImage carritoPlus;
	PImage carrito;
	PImage confirmar;
	PImage datos;
	PImage confirmacion;
	PImage fondo;
	PImage cancelar;
	PImage fin;
	PImage botonInicio;
	PImage comparacionS;
	PImage comparacionX;
	PImage comparacion3;
	PImage botonCarro;
	PImage fondoGraficas;
	PImage carroS;
	PImage carro3;
	PImage carroX;
	
 
	
	
public void settings() {
	size (350,600);
	
}

public void setup() {
	loginScreen= new LoginScreen(this);
	homeScreen=new HomeScreen(this);
	historialScreen = new HistorialScreen(this);
	catalogoScreen = new CatalogoScreen(this);
	catalogoSScreen = new CatalogoSScreen(this);
	catalogo3Screen = new Catalogo3Screen(this);
	catalogoXScreen = new CatalogoXScreen(this);
	carritoScreen = new CarritoScreen(this);
	datosScreen = new DatosScreen(this);
	confirmacionScreen = new ConfirmacionScreen(this);
	completoScreen = new CompletoScreen(this);
	comparacionCuadradosGraficaSScreen = new ComparacionCuadradosGraficaSScreen(this);
	
	logo = loadImage("imagenes/Mask Groupnegro.png");
	logoGris = loadImage("imagenes/Mask Group.png");
	
	entrar = loadImage("imagenes/entrar.png");
	espacio = loadImage("imagenes/Rectangle 1.png");
	inicio = loadImage("imagenes/inicio.png");
	casaNegra = loadImage("imagenes/home.png");
	casaBlanca = loadImage("imagenes/casaBlanca.png");
	carroNegro = loadImage("imagenes/shopping-cart (1).png");
	carroBlanco = loadImage("imagenes/Mask Group-1.png");
	tareaNegra = loadImage("imagenes/clipboard.png");
	tareaBlanca = loadImage("imagenes/Mask Group-2.png");
	historial = loadImage("imagenes/historialCompleto.png");
	back = loadImage("imagenes/flecha.png");
	ojo = loadImage("imagenes/ojo.png");
	catalogo = loadImage("imagenes/catalogo.png");
	carritoPlus = loadImage("imagenes/Group 1.png");
	carrito = loadImage("imagenes/carrito.png");
	confirmar = loadImage("imagenes/confirmar.png");
	datos = loadImage("imagenes/datosCompra.png");
	confirmacion = loadImage("imagenes/confirmacionDatos.png");
	fondo = loadImage("imagenes/gris.png");
	cancelar = loadImage("imagenes/cancelar.png");
	fin = loadImage("imagenes/completo.png");
	botonInicio = loadImage("imagenes/botonInicio.png");
	comparacionS = loadImage("imagenes/comparacionS.png");
	comparacionX = loadImage("imagenes/comparacionX.png");
	comparacion3 = loadImage("imagenes/comparacion3.png");
	botonCarro = loadImage("imagenes/botonCarro.png");
	fondoGraficas = loadImage("imagenes/fondoGrafica.png");
	carroS = loadImage("imagenes/Group 17.png");
	carro3 = loadImage("imagenes/Group 16.png");
	carroX = loadImage("imagenes/Group 15.png");
}

public void draw() {
	background(255);
	switch (pantalla) {
	case 0: //login
	loginScreen.draw();
	break;
	case 1: //Inicio
	homeScreen.draw();
	break;
	case 2: //historial
	historialScreen.draw();
	break;
	case 3: //catalogo
	catalogoScreen.draw();
		break;
	case 4: //catalogo S
	catalogoSScreen.draw();
		break;
	case 5: //catalogo 3
	catalogo3Screen.draw();

		break;
	case 6: //catalogo X
	catalogoXScreen.draw();
		break;
	case 7: //carrito
	carritoScreen.draw();
		break;
	case 8: //datos
		datosScreen.draw();
		break;
	case 9: //confirmacion
		confirmacionScreen.draw();
		break;
	case 10: //completo
		completoScreen.draw();
		break;
	case 11: //comparacionCuadradosgraficaS
		comparacionCuadradosGraficaSScreen.draw();
		break;
	case 12: //comparacionCuadradosgrafica3
		image(logoGris,94,200,160,200);
		image(comparacion3,0,0,350,600);
		image(tareaNegra,40,564,30,30);
		image(casaBlanca,160,564,30,30);
		image(carroNegro,281,564,30,30);
		image(back,25,60,30,30);
		image(ojo,296,60,30,30);
		image(carritoPlus,230,190,28,24);
		break;
	case 13: //comparacionCuadradosgraficaX
		image(logoGris,94,200,160,200);
		image(comparacionX,0,0,350,600);
		image(tareaNegra,40,564,30,30);
		image(casaBlanca,160,564,30,30);
		image(carroNegro,281,564,30,30);
		image(back,25,60,30,30);
		image(ojo,296,60,30,30);
		image(carritoPlus,230,190,28,24);
		break;
		}
	}
public void mousePressed() {
	switch(pantalla) {
	case 0: //login
		if(mouseX > 111 && mouseX < 251 && mouseY > 540 && mouseY < 585) {
	          pantalla = 1;
		}
		loginScreen.Click();
	break;
	case 1: //menuprincipal
		pantalla=homeScreen.Click(pantalla);
	break;
	case 2: //historia
		pantalla=historialScreen.Click(pantalla);
		break;
	case 3: //catalogos
		pantalla=catalogoScreen.Click(pantalla);
		break;
		
	case 4: //catalogoS
		pantalla=catalogoSScreen.Click(pantalla);
		 
		break;

	case 5: //catalogo3
		pantalla=catalogo3Screen.Click(pantalla);
		 
		break;

	case 6: //catalogox
		pantalla=catalogoXScreen.Click(pantalla);
		
		break;
	case 7: //carrito
		pantalla=carritoScreen.Click(pantalla);
		break;
	case 8: //datos
		pantalla=datosScreen.Click(pantalla);
		
		break;
	case 9: //confirmacion
		pantalla=confirmacionScreen.Click(pantalla);
		break;
	case 10: //completo
		pantalla=completoScreen.Click(pantalla);
		break;
	case 11: //comparacionCuadradosgraficaS
		pantalla=comparacionCuadradosGraficaSScreen.Click(pantalla);
		break;

	case 12: //comparacionCuadradosgrafica3
		if(mouseX > 40 && mouseX < 70 && mouseY > 564 && mouseY < 594) {
	          pantalla = 2; //historia 40,564,30,30
		} 
		if(mouseX > 160 && mouseX < 190 && mouseY > 564 && mouseY < 594) {
	          pantalla = 1; //catalogo 160,564,30,30
		} 
		if(mouseX > 281 && mouseX < 311 && mouseY > 564 && mouseY < 594) {
	          pantalla = 7; //carro  281,564,30,30
		} 
		if(mouseX > 296 && mouseX < 326 && mouseY > 60 && mouseY < 90) {
	          pantalla = 5; //boton ojo 296,60,30,30;
		} 
		if(mouseX > 25 && mouseX < 55 && mouseY > 60 && mouseY < 90) {
	          pantalla = 3; //(back,25,60,30,30);
		} 
		if(mouseX > 230 && mouseX < 258 && mouseY > 190 && mouseY < 214) {
	          pantalla = 7; //carritoCaja 230,190,28,24;
		}
		break;

	case 13: //comparacionCuadradosgraficax
		if(mouseX > 40 && mouseX < 70 && mouseY > 564 && mouseY < 594) {
	          pantalla = 2; //historia 40,564,30,30
		} 
		if(mouseX > 160 && mouseX < 190 && mouseY > 564 && mouseY < 594) {
	          pantalla = 1; //catalogo 160,564,30,30
		} 
		if(mouseX > 281 && mouseX < 311 && mouseY > 564 && mouseY < 594) {
	          pantalla = 7; //carro  281,564,30,30
		} 
		if(mouseX > 25 && mouseX < 55 && mouseY > 60 && mouseY < 90) {
	          pantalla = 3; //(back,25,60,30,30);
		} 
		if(mouseX > 296 && mouseX < 326 && mouseY > 60 && mouseY < 90) {
	          pantalla = 6; //boton ojo 296,60,30,30;
		}
		if(mouseX > 230 && mouseX < 258 && mouseY > 190 && mouseY < 214) {
	          pantalla = 7; //carritoCaja 230,190,28,24;
		}
		break; 

		}
	}

	public void keyTyped(){
		switch(pantalla) {
		case 0:
		
			loginScreen.Write(key);
			break;
		
		}
	}
}