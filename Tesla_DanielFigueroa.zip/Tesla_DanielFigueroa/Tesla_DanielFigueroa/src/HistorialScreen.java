import processing.core.PApplet;
import processing.core.PImage;

public class HistorialScreen {
	
	private PApplet app;
	private PImage logoGris;
	private PImage carroNegro;
	private PImage casaNegra;
	private PImage tareaBlanca;
	private PImage historial;
	private PImage back;


	public HistorialScreen(PApplet app){
		this.app=app;
		this.logoGris = app.loadImage("imagenes/Mask Group.png");
		this.casaNegra = app.loadImage("imagenes/home.png");
		this.carroNegro = app.loadImage("imagenes/shopping-cart (1).png");
		this.tareaBlanca = app.loadImage("imagenes/Mask Group-2.png");
		this.historial = app.loadImage("imagenes/historialCompleto.png");
		back = app.loadImage("imagenes/flecha.png");
	
	}
	
	public void draw() {
		app.image(logoGris,94,200,160,200);
		app.image(historial,0,0,350,600);
		app.image(tareaBlanca,40,564,30,30);
		app.image(casaNegra,160,564,30,30);
		app.image(carroNegro,281,564,30,30);
		app.image(back,25,60,30,30);
		
	}
	
	public int Click(int screen){
		if(app.mouseX > 40 && app.mouseX < 70 && app.mouseY > 564 && app.mouseY < 594) {
	          return 1; //historia 40,564,30,30
		} 
		if(app.mouseX > 160 && app.mouseX < 190 && app.mouseY > 564 && app.mouseY < 594) {
	          return 3; //catalogo 160,564,30,30
		} 
		if(app.mouseX > 281 && app.mouseX < 311 && app.mouseY > 564 && app.mouseY < 594) {
	          return 7; //carro  281,564,30,30
		}
		if(app.mouseX > 25 && app.mouseX < 55 && app.mouseY > 60 && app.mouseY < 90) {
	          return 1; //(back,25,60,30,30);
		} 
		
		return screen;
	
	}


}
