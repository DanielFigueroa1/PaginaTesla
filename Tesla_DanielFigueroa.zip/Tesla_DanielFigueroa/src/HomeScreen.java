import processing.core.PApplet;
import processing.core.PImage;

public class HomeScreen {
	
	private PApplet app;
	private PImage logoGris;
	private PImage carroNegro;
	private PImage casaNegra;
	private PImage tareaNegra;
	private PImage inicio;

	public HomeScreen(PApplet app){
		this.app=app;
		this.inicio = app.loadImage("imagenes/inicio.png");
		this.logoGris = app.loadImage("imagenes/Mask Group.png");
		this.casaNegra = app.loadImage("imagenes/home.png");
		this.carroNegro = app.loadImage("imagenes/shopping-cart (1).png");
		this.tareaNegra = app.loadImage("imagenes/clipboard.png");
	
	}
	
	public void draw() {
		app.image(logoGris,94,200,160,200);
		app.image(inicio,0,0,350,600);
		app.image(casaNegra,160,564,30,30);
		app.image(tareaNegra,40,564,30,30);
		app.image(carroNegro,281,564,30,30);
		
	}
	
	public int Click(int screen){
		if(app.mouseX > 40 && app.mouseX < 70 && app.mouseY > 564 && app.mouseY < 594) {
	          return 2; //historia 40,564,30,30
		} 
		if(app.mouseX > 160 && app.mouseX < 190 && app.mouseY > 564 && app.mouseY < 594) {
	          return 3; //catalogo 160,564,30,30
		} 
		if(app.mouseX > 281 && app.mouseX < 311 && app.mouseY > 564 && app.mouseY < 594) {
	          return 7; //carro  281,564,30,30
		}
		
		return screen;
	
	}


}
