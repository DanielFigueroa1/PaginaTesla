import processing.core.PApplet;
import processing.core.PImage;

public class LoginScreen {
	
	private PApplet app;
	private PImage login;
	private Button boton;
	private Input[] inputs;

	public LoginScreen(PApplet app){
		this.app=app;
		this.login = app.loadImage("imagenes/login.png");
		this.boton = new Button(111,540,140,45, "Entrar", app);
		this.boton.setColor(255);
		this.inputs= new Input [2];
		this.inputs[0] = new Input(56,310,250,50, 0, app);
		this.inputs[1] = new Input(56,420,250,50, 1, app);
		this.inputs[0].setColor(255);
		this.inputs[1].setColor(255);
		this.inputs[0].setTextColor(0);
		this.inputs[1].setTextColor(0);
	}
	
	public void draw() {
		app.image(login,70,20,220,380);
		boton.draw();
	    inputs[0].draw();
	    inputs[1].draw();
		/*
		app.image(entrar,111,540,140,45);
		
		app.image(espacio,56,310,250,50);
		app.image(espacio,56,420,250,50);
		*/
	}
	
	public void Click(){
		if(boton.over()){
			
		}
		 inputs[0].setFocus();
		 inputs[1].setFocus();
	}
	
	public void Write(char key){
		System.out.println(key);
		this.inputs[0].writeText(key);
		this.inputs[1].writeText(key);
	}

}
