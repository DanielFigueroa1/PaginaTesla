import processing.core.PApplet;

public class Logica {
	
	private PApplet app;

	public Logica(PApplet app){
		this.app=app;
	}
	
	
}
