
public class Logica {

}
