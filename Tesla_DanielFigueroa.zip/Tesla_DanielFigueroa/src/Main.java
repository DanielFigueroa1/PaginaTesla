import processing.core.PApplet;
import processing.core.PImage;

public class Main extends PApplet {

	public static void main(String[] args) {

		PApplet.main("Main"); // no s� como es pero debo hacerlo

		
	}
	
	int pantalla;
	PImage logo;
	PImage logoGris;
	PImage login;
	PImage entrar;
	PImage espacio;
	PImage inicio;
	PImage casaNegra;
	PImage carroNegro;
	PImage tareaNegra;
	PImage tareaBlanca;
	PImage historial;
	PImage back;
	
public void settings() {
	size (350,600);
	
}

public void setup() {
	logo = loadImage("imagenes/Mask Groupnegro.png");
	logoGris = loadImage("imagenes/Mask Group.png");
	login = loadImage("imagenes/login.png");
	entrar = loadImage("imagenes/entrar.png");
	espacio = loadImage("imagenes/Rectangle 1.png");
	inicio = loadImage("imagenes/inicio.png");
	casaNegra = loadImage("imagenes/home.png");
	carroNegro = loadImage("imagenes/shopping-cart (1).png");
	tareaNegra = loadImage("imagenes/clipboard.png");
	tareaBlanca = loadImage("imagenes/Mask Group-2.png");
	historial = loadImage("imagenes/historialCompleto.png");
	back = loadImage("imagenes/flecha.png");
	
}

public void draw() {
	background(255);
	switch (pantalla) {
	case 2: //login
	image(login,70,50,220,380);
	image(entrar,111,540,140,45);
	image(espacio,56,340,250,50);
	image(espacio,56,450,250,50);
	break;
	case 1: //Inicio
		image(logoGris,94,200,160,200);
		image(inicio,0,0,350,600);
		image(casaNegra,160,564,30,30);
		image(tareaNegra,40,564,30,30);
		image(carroNegro,270,564,30,30);
	break;
	case 0: //historial
		image(historial,0,0,350,600);
		image(tareaBlanca,40,564,30,30);
		image(casaNegra,160,564,30,30);
		image(carroNegro,270,564,30,30);
		image(back,25,60,30,30);
	break;
	case 3: 
		
		break;
		}
	}
}