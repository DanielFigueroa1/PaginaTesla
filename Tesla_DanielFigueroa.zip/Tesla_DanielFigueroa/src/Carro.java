import processing.core.PApplet;
import processing.core.PImage;

public class Carro {
	
	private PImage image;
	private String name;
	PApplet app;
	
	public Carro(PImage image, String name) {
		this.image=image;
		this.name=name;
		
	}

}
