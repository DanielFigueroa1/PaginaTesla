import processing.core.PApplet;
import processing.core.PImage;

public class ComparacionCuadradosGrafica3Screen {

	private PApplet app;
	private PImage logoGris;
	private PImage comparacion3;
	private PImage tareaNegra;
	private PImage casaBlanca;
	private PImage carroNegro;
	private PImage back;
	private PImage ojo;
	private PImage carritoPlus;

	public ComparacionCuadradosGrafica3Screen(PApplet app) {
		this.app = app;
		this.logoGris = app.loadImage("imagenes/Mask Group.png");
		this.comparacion3 = app.loadImage("imagenes/comparacion3.png");
		this.tareaNegra = app.loadImage("imagenes/clipboard.png");
		this.casaBlanca = app.loadImage("imagenes/casaBlanca.png");
		this.carroNegro = app.loadImage("imagenes/shopping-cart (1).png");
		this.back = app.loadImage("imagenes/flecha.png");
		this.ojo = app.loadImage("imagenes/ojo.png");
		this.carritoPlus = app.loadImage("imagenes/Group 1.png");
	}

	public void draw() {
		app.image(logoGris, 94, 200, 160, 200);
		app.image(comparacion3, 0, 0, 350, 600);
		app.image(tareaNegra, 40, 564, 30, 30);
		app.image(casaBlanca, 160, 564, 30, 30);
		app.image(carroNegro, 281, 564, 30, 30);
		app.image(back, 25, 60, 30, 30);
		app.image(ojo, 296, 60, 30, 30);
		app.image(carritoPlus, 230, 190, 28, 24);
	}

	public int Click(int screen) {

		if (app.mouseX > 40 && app.mouseX < 70 && app.mouseY > 564 && app.mouseY < 594) {
			return 2; // historia 40,564,30,30
		}
		if (app.mouseX > 160 && app.mouseX < 190 && app.mouseY > 564 && app.mouseY < 594) {
			return 1; // catalogo 160,564,30,30
		}
		if (app.mouseX > 281 && app.mouseX < 311 && app.mouseY > 564 && app.mouseY < 594) {
			return 7; // carro 281,564,30,30
		}
		if (app.mouseX > 296 && app.mouseX < 326 && app.mouseY > 60 && app.mouseY < 90) {
			return 5; // boton ojo 296,60,30,30;
		}
		if (app.mouseX > 25 && app.mouseX < 55 && app.mouseY > 60 && app.mouseY < 90) {
			return 3; // (back,25,60,30,30);
		}
		if (app.mouseX > 230 && app.mouseX < 258 && app.mouseY > 190 && app.mouseY < 214) {
			return 7; // carritoCaja 230,190,28,24;
		}

		return screen;

	}
}
