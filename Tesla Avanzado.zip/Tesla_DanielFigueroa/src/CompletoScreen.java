import processing.core.PApplet;
import processing.core.PImage;

public class CompletoScreen {
	
	private PApplet app;
	private PImage fin;
	private PImage botonInicio;
	
	public CompletoScreen(PApplet app){
		this.app = app;
		this.fin = app.loadImage("imagenes/completo.png");
		this.botonInicio = app.loadImage("imagenes/botonInicio.png");
	}
	
	public void draw() {
		app.image(fin,76,60,200,300);
		app.image(botonInicio,111,440,130,40);
	}
	
	public int Click(int screen) {

		if(app.mouseX > 111 && app.mouseX < 241 && app.mouseY > 440 && app.mouseY < 480) {
	          return 1; //Reinicio 111,440,130,40);
		}
		
		return screen;

	}
}
