import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

public class Logica {
	
	ArrayList<User> usuarios= new ArrayList<User>();
	private PApplet app;

	public Logica(PApplet app){
		this.app=app;
	}
	
	public boolean CrearUsuario(String userName, String password ){
		
		if(userName != "" && password != "") {
			usuarios.add(new User(userName,password));
			for(int i=0;i<usuarios.size();i++) {
				usuarios.get(i).setLogin(false);
				System.out.println(usuarios.size());
			}
			usuarios.get(usuarios.size()-1).setLogin(true);
			
			return true;
		}else {
			System.out.println("malo");
			System.out.println(usuarios.size());
			return false;
		}
		
	}
	
	
	public void addCar(PImage img, String Name ){
		for(int i=0;i<usuarios.size();i++) {
			if(usuarios.get(i).isLogin()) {
				usuarios.get(i).CreateCar(img, Name);
			}
		}
	}

	public ArrayList<User> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(ArrayList<User> usuarios) {
		this.usuarios = usuarios;
	}
	
	
	
}
