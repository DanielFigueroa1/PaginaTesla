import java.util.ArrayList;

import processing.core.PImage;

public class User {
	
	private String email;
	private String password;
	private boolean isLogin;
	
	private ArrayList<Carro> carros = new ArrayList<Carro>();
	
	public User(String email, String password) {
		this.email=email;
		this.password=password;
	}
	
	public void CreateCar(PImage img, String name){
		carros.add(new Carro(img, name));
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isLogin() {
		return isLogin;
	}

	public void setLogin(boolean isLogin) {
		this.isLogin = isLogin;
	}

	public ArrayList<Carro> getCarros() {
		return carros;
	}

	public void setCarros(ArrayList<Carro> carros) {
		this.carros = carros;
	}



}
