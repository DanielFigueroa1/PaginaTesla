
import processing.core.PApplet;

public class Button {

    private int posX;
    private int posY;
    private int width;
    private int height;
    private String text;
    private boolean focus;
    private PApplet app;

    private int colorMode;
    private int color;
    private int r;
    private int g;
    private int b;

    private int textColorMode;
    private int textColor;
    private int textR;
    private int textG;
    private int textB;

    public Button(int posX, int posY, int width, int height, String text, PApplet app){
        this.posX=posX;
        this.posY=posY;
        this.width=width;
        this.height=height;
        this.text=text;
        this.app=app;

        this.colorMode=0;
        this.color=200;

        this.textColorMode =0;
        this.textColor=0;
    }

    public void draw(){
        app.noStroke();
        switch (colorMode){
            case 0:
                if(focus){
                    app.fill(color-20);
                }else{
                    app.fill(color);
                }
                break;
            case 1:
                if(focus){
                    app.fill(r-20,g-20,b-20);
                }else{
                    app.fill(r,g,b);
                }
                break;
        }
        setFocus();
        app.strokeWeight(3);
        app.stroke(0);
        app.rect(posX,posY,width,height,height/2);
        switch (textColorMode){
            case 0:
                app.fill(textColor);
                break;
            case 1:
                app.fill(textR, textG, textB);
                break;
        }
        app.textAlign(app.CENTER,app.CENTER);
        app.text(text,this.posX+(width/2),this.posY+(height/2)-(height/15));
    }

    public void setColor(int color){
        this.color =color;
        colorMode=0;
    }

    public void setColor(int r, int g, int b){
        this.r=r;
        this.g=g;
        this.b=b;
        colorMode=1;
    }

    public void setTextColor(int color){
        textColor=color;
        textColorMode =0;
    }

    public void setTextColor(int r, int g, int b){
        textR =r;
        textG =g;
        textB =b;
        textColorMode =1;
    }

    public boolean over(){
        return app.mouseX > posX && app.mouseX < posX + width &&
                app.mouseY > posY && app.mouseY < posY + height;
    }

    public void setFocus(){
        focus= app.mouseX > posX && app.mouseX < posX + width &&
                app.mouseY > posY && app.mouseY < posY + height;
    }



}
