import processing.core.PApplet;
import processing.core.PImage;

public class DatosScreen {
	
	private PApplet app;
	private PImage logoGris;
	private PImage espacio;
	private PImage datos;
	private PImage back;
	private PImage tareaNegra;
	private PImage casaNegra;
	private PImage carroBlanco;
	private PImage confirmar;
	
	public DatosScreen(PApplet app){
		this.app = app;
		this.logoGris = app.loadImage("imagenes/Mask Group.png");
		this.tareaNegra = app.loadImage("imagenes/clipboard.png");
		this.espacio = app.loadImage("imagenes/Rectangle 1.png");
		this.datos = app.loadImage("imagenes/datosCompra.png");
		this.back = app.loadImage("imagenes/flecha.png");
		this.casaNegra = app.loadImage("imagenes/home.png");
		this.carroBlanco = app.loadImage("imagenes/Mask Group-1.png");
		this.confirmar = app.loadImage("imagenes/confirmar.png");
	}
	
	public void draw() {
		app.image(logoGris,94,200,160,200);
		app.image(espacio,50,165,250,50);
		app.image(espacio,50,256,250,50);
		app.image(espacio,50,344,250,50);
		app.image(datos,0,0,350,600);
		app.image(back,25,60,30,30);
		app.image(tareaNegra,40,564,30,30);
		app.image(casaNegra,160,564,30,30);
		app.image(carroBlanco,281,564,30,30);
		app.image(confirmar,111,500,130,40);
	}
	
	public int Click(int screen) {
		if(app.mouseX > 40 && app.mouseX < 70 && app.mouseY > 564 && app.mouseY < 594) {
			return 2; //historia 40,564,30,30
		} 
		if(app.mouseX > 160 && app.mouseX < 190 && app.mouseY > 564 && app.mouseY < 594) {
			return 3; //catalogo 160,564,30,30
		} 
		if(app.mouseX > 281 && app.mouseX < 311 && app.mouseY > 564 && app.mouseY < 594) {
			return 1; //carro  281,564,30,30
		} 
		if(app.mouseX > 25 && app.mouseX < 55 && app.mouseY > 60 && app.mouseY < 90) {
	          return 1; //(back,25,60,30,30);
		} 
		if(app.mouseX > 111 && app.mouseX < 241 && app.mouseY > 500 && app.mouseY < 540) {
			return 9; //Confirmar 111,500,130,40);
		} 
		return screen;

	}
}
