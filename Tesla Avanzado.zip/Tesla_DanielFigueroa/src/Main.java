import processing.core.PApplet;
import processing.core.PImage;

public class Main extends PApplet {

	public static void main(String[] args) {

		PApplet.main("Main"); // no s� como es pero debo hacerlo

		//LETRA ROBOTO
	}
	
	int pantalla;
	LoginScreen loginScreen;
	HomeScreen homeScreen;
	HistorialScreen historialScreen;
	CatalogoScreen catalogoScreen;
	CatalogoSScreen catalogoSScreen;
	Catalogo3Screen catalogo3Screen;
	CatalogoXScreen catalogoXScreen;
	CarritoScreen carritoScreen;
	DatosScreen datosScreen;
	ConfirmacionScreen confirmacionScreen;
	CompletoScreen completoScreen;
	ComparacionCuadradosGraficaSScreen comparacionCuadradosGraficaSScreen;
	ComparacionCuadradosGrafica3Screen comparacionCuadradosGrafica3Screen;
	ComparacionCuadradosGraficaXScreen comparacionCuadradosGraficaXScreen;
	
	Logica logica;
	private PImage carroS;
	private PImage carroX;
	private PImage carro3;
	
public void settings() {
	size (350,600);
	
}

public void setup() {
	loginScreen= new LoginScreen(this);
	homeScreen=new HomeScreen(this);
	historialScreen = new HistorialScreen(this);
	catalogoScreen = new CatalogoScreen(this);
	catalogoSScreen = new CatalogoSScreen(this);
	catalogo3Screen = new Catalogo3Screen(this);
	catalogoXScreen = new CatalogoXScreen(this);
	carritoScreen = new CarritoScreen(this);
	datosScreen = new DatosScreen(this);
	confirmacionScreen = new ConfirmacionScreen(this);
	completoScreen = new CompletoScreen(this);
	comparacionCuadradosGraficaSScreen = new ComparacionCuadradosGraficaSScreen(this);
	comparacionCuadradosGrafica3Screen= new ComparacionCuadradosGrafica3Screen(this);
	comparacionCuadradosGraficaXScreen = new ComparacionCuadradosGraficaXScreen(this);
	
	logica=  new Logica(this);
	pantalla=0;
	carroS = loadImage("imagenes/Group 17.png");
	carro3 = loadImage("imagenes/Group 16.png");
	carroX = loadImage("imagenes/Group 15.png");
	/*
	logo = loadImage("imagenes/Mask Groupnegro.png");
	logoGris = loadImage("imagenes/Mask Group.png");
	
	entrar = loadImage("imagenes/entrar.png");
	espacio = loadImage("imagenes/Rectangle 1.png");
	inicio = loadImage("imagenes/inicio.png");
	casaNegra = loadImage("imagenes/home.png");
	casaBlanca = loadImage("imagenes/casaBlanca.png");
	carroNegro = loadImage("imagenes/shopping-cart (1).png");
	carroBlanco = loadImage("imagenes/Mask Group-1.png");
	tareaNegra = loadImage("imagenes/clipboard.png");
	tareaBlanca = loadImage("imagenes/Mask Group-2.png");
	historial = loadImage("imagenes/historialCompleto.png");
	back = loadImage("imagenes/flecha.png");
	ojo = loadImage("imagenes/ojo.png");
	catalogo = loadImage("imagenes/catalogo.png");
	carritoPlus = loadImage("imagenes/Group 1.png");
	carrito = loadImage("imagenes/carrito.png");
	confirmar = loadImage("imagenes/confirmar.png");
	datos = loadImage("imagenes/datosCompra.png");
	confirmacion = loadImage("imagenes/confirmacionDatos.png");
	fondo = loadImage("imagenes/gris.png");
	cancelar = loadImage("imagenes/cancelar.png");
	fin = loadImage("imagenes/completo.png");
	botonInicio = loadImage("imagenes/botonInicio.png");
	comparacionS = loadImage("imagenes/comparacionS.png");
	comparacionX = loadImage("imagenes/comparacionX.png");
	comparacion3 = loadImage("imagenes/comparacion3.png");
	botonCarro = loadImage("imagenes/botonCarro.png");
	fondoGraficas = loadImage("imagenes/fondoGrafica.png");
	*/
}

public void draw() {
	background(255);
	switch (pantalla) {
	case 0: //login
	loginScreen.draw();
	break;
	case 1: //Inicio
	homeScreen.draw();
	break;
	case 2: //historial
	historialScreen.draw();
	break;
	case 3: //catalogo
	catalogoScreen.draw();
		break;
	case 4: //catalogo S
	catalogoSScreen.draw();
	
		break;
	case 5: //catalogo 3
	catalogo3Screen.draw();

		break;
	case 6: //catalogo X
	catalogoXScreen.draw();
	
		break;
	case 7: //carrito
	carritoScreen.draw(logica);
	
		break;
	case 8: //datos
		datosScreen.draw();
		break;
	case 9: //confirmacion
		confirmacionScreen.draw();
		break;
	case 10: //completo
		completoScreen.draw();
		break;
	case 11: //comparacionCuadradosgraficaS
		comparacionCuadradosGraficaSScreen.draw();
		break;
	case 12: //comparacionCuadradosgrafica3
		comparacionCuadradosGrafica3Screen.draw();
		break;
	case 13: //comparacionCuadradosgraficaX
		comparacionCuadradosGraficaXScreen.draw();
		break;
		}
	}
public void mousePressed() {
	switch(pantalla) {
	case 0: //login
		if(loginScreen.getBoton().over()) {
	         if(logica.CrearUsuario(loginScreen.getInputs()[0].getText(),loginScreen.getInputs()[1].getText()) ) {
	        	 pantalla=1;
	         }
		}
		loginScreen.Click();
	break;
	case 1: //menuprincipal
		pantalla=homeScreen.Click(pantalla);
	break;
	case 2: //historia
		pantalla=historialScreen.Click(pantalla);
		break;
	case 3: //catalogos
		pantalla=catalogoScreen.Click(pantalla);
		break;
		
	case 4: //catalogoS
		pantalla=catalogoSScreen.Click(pantalla);
		 
		break;

	case 5: //catalogo3
		pantalla=catalogo3Screen.Click(pantalla);
		 
		break;

	case 6: //catalogox
		pantalla=catalogoXScreen.Click(pantalla);
		
		break;
	case 7: //carrito
		pantalla=carritoScreen.Click(pantalla);
		break;
	case 8: //datos
		pantalla=datosScreen.Click(pantalla);
		
		break;
	case 9: //confirmacion
		pantalla=confirmacionScreen.Click(pantalla);
		break;
	case 10: //completo
		pantalla=completoScreen.Click(pantalla);
		break;
	case 11: //comparacionCuadradosgraficaS
		pantalla=comparacionCuadradosGraficaSScreen.Click(pantalla);
		break;

	case 12: //comparacionCuadradosgrafica3
		pantalla=comparacionCuadradosGrafica3Screen.Click(pantalla);
		break;

	case 13: //comparacionCuadradosgraficax
		pantalla=comparacionCuadradosGraficaXScreen.Click(pantalla);
		break; 

		}
	}

	public void keyTyped(){
		switch(pantalla) {
		case 0:
		
			loginScreen.Write(key);
			break;
		
		}
	}
}