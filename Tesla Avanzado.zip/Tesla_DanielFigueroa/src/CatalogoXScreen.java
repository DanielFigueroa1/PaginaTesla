import processing.core.PApplet;
import processing.core.PImage;

public class CatalogoXScreen {
	
	private PApplet app;
	private PImage logoGris;
	private PImage carroNegro;
	private PImage back;
	private PImage casaBlanca;
	private PImage tareaNegra;
	private PImage fondoGraficas;
	private boolean crearX;



	public CatalogoXScreen(PApplet app){
		this.app=app;
		this.logoGris = app.loadImage("imagenes/Mask Group.png");
		this.carroNegro = app.loadImage("imagenes/shopping-cart (1).png");
		this.casaBlanca = app.loadImage("imagenes/casaBlanca.png");
		this.tareaNegra = app.loadImage("imagenes/clipboard.png");
		this.back = app.loadImage("imagenes/flecha.png");
		this.fondoGraficas = app.loadImage("imagenes/fondoGrafica.png");
	
	}
	
	public void draw() {
		app.image(logoGris,94,200,160,200);
		app.image(fondoGraficas,0,0,350,600);
		app.image(tareaNegra,40,564,30,30);
		app.image(casaBlanca,160,564,30,30);
		app.image(carroNegro,281,564,30,30);
		app.image(back,25,60,30,30);

	}
	
	public int Click(int screen){
		if(app.mouseX > 40 && app.mouseX < 70 && app.mouseY > 564 && app.mouseY < 594) {
	          return 2; //historia 40,564,30,30
		} 
		if(app.mouseX > 160 && app.mouseX < 190 && app.mouseY > 564 && app.mouseY < 594) {
	          return 1; //catalogo 160,564,30,30
		} 
		if(app.mouseX > 281 && app.mouseX < 311 && app.mouseY > 564 && app.mouseY < 594) {
	        crearX=true; 
			return 7; //carro  281,564,30,30
		} 
		if(app.mouseX > 25 && app.mouseX < 55 && app.mouseY > 60 && app.mouseY < 90) {
	          return 13; //(back,25,60,30,30);
		} 
		
		return screen;
	
	}

	public boolean isCrearX() {
		return crearX;
	}

	public void setCrearX(boolean crearX) {
		this.crearX = crearX;
	}
	
	


}
