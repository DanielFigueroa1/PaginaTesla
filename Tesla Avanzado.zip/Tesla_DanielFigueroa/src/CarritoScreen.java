import processing.core.PApplet;
import processing.core.PImage;

public class CarritoScreen {
	
	private PApplet app;
	private PImage logoGris;
	private PImage back;
	private PImage tareaNegra;
	private PImage carrito;
	private PImage casaNegra;
	private PImage carroBlanco;
	private PImage confirmar;


	public CarritoScreen(PApplet app){
		this.app=app;
		this.logoGris = app.loadImage("imagenes/Mask Group.png");
		this.tareaNegra = app.loadImage("imagenes/clipboard.png");
		this.back = app.loadImage("imagenes/flecha.png");
		this.carrito = app.loadImage("imagenes/carrito.png");
		this.casaNegra = app.loadImage("imagenes/home.png");
		this.carroBlanco = app.loadImage("imagenes/Mask Group-1.png");
		this.confirmar = app.loadImage("imagenes/confirmar.png");
	}
	
	public void draw(Logica logica) {
		app.image(logoGris,94,200,160,200);
		app.image(carrito,0,0,350,600);
		app.image(back,25,60,30,30);
		app.image(tareaNegra,40,564,30,30);
		app.image(casaNegra,160,564,30,30);
		app.image(carroBlanco,281,564,30,30);
		app.image(confirmar,111,500,130,40);
		
		for(int i=0;i<logica.getUsuarios().size();i++) {
			if(logica.getUsuarios().get(i).isLogin()) {
				
				for(int j=0;j<logica.getUsuarios().get(i).getCarros().size();j++) {
					
					logica.getUsuarios().get(i).getCarros().get(j).draw(145, 200+(j*200));
					
				}
				
			}
		}
		
	}
	
	public int Click(int screen){
		if(app.mouseX > 40 && app.mouseX < 70 && app.mouseY > 564 && app.mouseY < 594) {
	          return 2; //historia 40,564,30,30
		} 
		if(app.mouseX > 160 && app.mouseX < 190 && app.mouseY > 564 && app.mouseY < 594) {
			return 3; //catalogo 160,564,30,30
		} 
		if(app.mouseX > 281 && app.mouseX < 311 && app.mouseY > 564 && app.mouseY < 594) {
			return 1; //carro  281,564,30,30
		} 
		if(app.mouseX > 25 && app.mouseX < 55 && app.mouseY > 60 && app.mouseY < 90) {
			return 1; //(back,25,60,30,30);
		} 
		if(app.mouseX > 111 && app.mouseX < 241 && app.mouseY > 500 && app.mouseY < 540) {
			return 8; //Confirmar 111,500,130,40);
		} 
		return screen;
	
	}


}
